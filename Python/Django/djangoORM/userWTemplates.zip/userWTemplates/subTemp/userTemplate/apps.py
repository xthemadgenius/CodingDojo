from django.apps import AppConfig


class UsertemplateConfig(AppConfig):
    name = 'userTemplate'
