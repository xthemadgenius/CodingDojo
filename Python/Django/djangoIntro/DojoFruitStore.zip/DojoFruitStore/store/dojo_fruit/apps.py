from django.apps import AppConfig


class DojoFruitConfig(AppConfig):
    name = 'dojo_fruit'
