from django.apps import AppConfig


class FirstprojConfig(AppConfig):
    name = 'firstProj'
