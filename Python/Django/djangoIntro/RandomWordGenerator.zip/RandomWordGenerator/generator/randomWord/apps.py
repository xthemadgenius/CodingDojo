from django.apps import AppConfig


class RandomwordConfig(AppConfig):
    name = 'randomWord'
