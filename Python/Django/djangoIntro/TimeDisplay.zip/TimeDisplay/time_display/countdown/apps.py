from django.apps import AppConfig


class CountdownConfig(AppConfig):
    name = 'countdown'
